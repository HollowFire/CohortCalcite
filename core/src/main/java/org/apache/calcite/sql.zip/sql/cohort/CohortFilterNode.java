package org.apache.calcite.sql.cohort;

import org.apache.calcite.sql.SqlCohortNode;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 * A <code>CohortFilterNode</code> is a node of a parse tree which represents a filter in cohort query.
 */


public class CohortFilterNode extends SqlCohortNode {
	
    public String type;
    public String dimension;
    public List<String> values;

    public List<CohortFilterNode> fields;
    public boolean birthFunc = false;	

	public CohortFilterNode(String type) {
		this.type = type;
	}
	
	public String toString() {
		return getJson().toString(2);
	}
	
	public JSONObject getJson() {
        Map<String, Object> map = new LinkedHashMap<>();
        map.put("type", type);
        if (dimension != null) {
            map.put("dimension", dimension);
        }
        if (values != null) {
        	JSONArray valueArray = new JSONArray();
            for (String x: values) {
            	valueArray.put(x);
            }
            map.put("values", valueArray);
        }
        if (fields != null) {
			JSONArray fieldArray = new JSONArray();
			for (CohortFilterNode item:fields) {
				fieldArray.put(item.getJson());
			}
			map.put("fields", fieldArray);
        }
        return new JSONObject(map);
    }
	
}
		
	
	
	