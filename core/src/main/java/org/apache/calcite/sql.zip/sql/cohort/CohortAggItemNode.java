package org.apache.calcite.sql.cohort;

import org.apache.calcite.sql.SqlCohortNode;


public class CohortAggItemNode extends SqlCohortNode {
	public String type;
	//COHORTSIZE, AGE, USERCOUNT, LONG_SUM, DOUBLE_SUM, MIN, MAX, AVG
	public String fieldName;
	

	public CohortAggItemNode(String type) {
		this.type = type;
	}
	
}
	
	