package org.apache.calcite.sql.cohort;

import org.apache.calcite.sql.SqlCohortNode;

public class CohortIdentifierNode extends SqlCohortNode {
	
	public String value;
	
	public CohortIdentifierNode(String value) {
		this.value = value;
	}
	
	public String toString() {
		return value;
	}
}